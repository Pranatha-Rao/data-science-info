INFO6105 Assignment 2 done by:
Mourya Pratap Reddy Dasarapalli (001029868)
Pranatha Rajaprasad Rao (001023759)

1. Downloaded 3 .txt files of stocks of 3 different companies from kaggle
2. Plotted closing prices, modeled them with either simple or double exponential smoothing, and tested to see if they're stationary.
3. Used a random forest from Scikit-learn to predict stock prices for the three chosen stocks.

